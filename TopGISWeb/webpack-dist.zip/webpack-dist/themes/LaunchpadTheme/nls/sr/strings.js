define({
  "_themeLabel": "Tema trake za pokretanje",
  "_layout_default": "Podrazumevani raspored",
  "_layout_right": "Desni raspored"
});